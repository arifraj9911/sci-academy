const faqData = [
  {
    number: "01",
    question: "Lorem ipsum dolor sit amet consectetur.",
    answer: "Fringilla at purus nisl turpis mattis.",
  },
  {
    number: "02",
    question: "Lorem ipsum dolor sit amet consectetur.",
    answer:
      "Elementum in nisi ipsum turpis purus. Curabitur fusce sapien arcu egestas viverra. Blandit lectus vitae sed amet sit nibh porta aliquam. Vivamus nibh senectus et enim varius est.",
  },
  {
    number: "03",
    question: "Lorem ipsum dolor sit amet consectetur.",
    answer: "Fringilla at purus nisl turpis mattis.",
  },
  {
    number: "04",
    question: "Lorem ipsum dolor sit amet consectetur.",
    answer: "Fringilla at purus nisl turpis mattis.",
  },
  {
    number: "05",
    question: "Lorem ipsum dolor sit amet consectetur.",
    answer: "Fringilla at purus nisl turpis mattis.",
  },
  {
    number: "06",
    question: "Lorem ipsum dolor sit amet consectetur.",
    answer: "Fringilla at purus nisl turpis mattis.",
  },
];

export default faqData;
